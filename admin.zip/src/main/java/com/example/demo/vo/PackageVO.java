package com.example.demo.vo;

public class PackageVO {
    private Long id;
    private String name;
    private Long hallId;
    private Long studioId;
    private Long dressId;
    private Long makeupId;
	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}

    // getter/setter
}
