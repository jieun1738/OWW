package com.example.demo.vo;

public class LoanVO {
    private Long id;
    private String userEmail;
    private Integer amount;
    private String status; // WAIT, APPROVED, REJECTED

    // getter/setter
}
